Filelist:
PIC16F18446_Curiosity_Nano_layer_plots_release_rev7.pdf : PCB Layer Plots
PIC16F18446_Curiosity_Nano_design_documentation_release_rev7.pdf : Design Documentation with Bom
BOM\Bill of Materials Print- PIC16F18446_Curiosity_Nano_release_rev7.xls : BOM, fitted components
ExportSTEP\PIC16F18446_Curiosity_Nano_release_rev7.step : 3D Model of PCBA
NC Drill\PIC16F18446_Curiosity_Nano_-RoundHoles_release_rev7.txt : Drill files, ASCII-RoundHoles
NC Drill\PIC16F18446_Curiosity_Nano_-SlotHoles_release_rev7.txt : Drill files, ASCII-SlotHoles
NC Drill\PIC16F18446_Curiosity_Nano_release_rev7.drl : Drill files, gerber
NC Drill\PIC16F18446_Curiosity_Nano_release_rev7.drr : Drill Files Report
ODB\PIC16F18446_Curiosity_Nano_release_rev7.zip : ODB++ Files
Pick Place\Pick Place for PIC16F18446_Curiosity_Nano_release_rev7.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for PIC16F18446_Curiosity_Nano_release_rev7.txt : Assembly Testpoint report, txt
Test Points\Assembly Testpoint Report for PIC16F18446_Curiosity_Nano_release_rev7.csv : Assembly Testpoint report, csv
Gerber\PIC16F18446_Curiosity_Nano_release_rev7.GP2 : Gerber files for Power Plane
Gerber\PIC16F18446_Curiosity_Nano_release_rev7.GP1 : Gerber files for Ground Plane
Gerber\PIC16F18446_Curiosity_Nano_release_rev7.GTS : Gerber files for Top Solder
Gerber\PIC16F18446_Curiosity_Nano_release_rev7.GBS : Gerber files for Bottom Solder
Gerber\PIC16F18446_Curiosity_Nano_release_rev7.GM1 : Gerber files for Board (M1)
Gerber\PIC16F18446_Curiosity_Nano_release_rev7.GBL : Gerber files for Bottom Layer
Gerber\PIC16F18446_Curiosity_Nano_release_rev7.GBO : Gerber files for Bottom Overlay
Gerber\PIC16F18446_Curiosity_Nano_release_rev7.GTP : Gerber files for Top Paste
Gerber\PIC16F18446_Curiosity_Nano_release_rev7.GTO : Gerber files for Top Overlay
Gerber\PIC16F18446_Curiosity_Nano_release_rev7.GTL : Gerber files for Top-Layer
NC Drill\PIC16F18446_Curiosity_Nano_release_rev7.LDP : Layer Pairs Definition
