Filelist:
PIC16F18446_Curiosity_Nano_layer_plots_release_rev8.pdf : PCB Layer Plots
PIC16F18446_Curiosity_Nano_design_documentation_release_rev8.pdf : Design Documentation with Bom
BOM\Bill of Materials Print- PIC16F18446_Curiosity_Nano_release_rev8.xls : BOM, fitted components
ExportSTEP\PIC16F18446_Curiosity_Nano_release_rev8.step : 3D Model of PCBA
NC Drill\PIC16F18446_Curiosity_Nano_-RoundHoles_release_rev8.txt : Drill files, ASCII-RoundHoles
NC Drill\PIC16F18446_Curiosity_Nano_-SlotHoles_release_rev8.txt : Drill files, ASCII-SlotHoles
NC Drill\PIC16F18446_Curiosity_Nano_release_rev8.drl : Drill files, gerber
NC Drill\PIC16F18446_Curiosity_Nano_release_rev8.drr : Drill Files Report
ODB\PIC16F18446_Curiosity_Nano_release_rev8.zip : ODB++ Files
Pick Place\Pick Place for PIC16F18446_Curiosity_Nano_release_rev8.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for PIC16F18446_Curiosity_Nano_release_rev8.txt : Assembly Testpoint report, txt
Test Points\Assembly Testpoint Report for PIC16F18446_Curiosity_Nano_release_rev8.csv : Assembly Testpoint report, csv
Gerber\PIC16F18446_Curiosity_Nano_release_rev8.GP2 : Gerber files for Power Plane
Gerber\PIC16F18446_Curiosity_Nano_release_rev8.GP1 : Gerber files for Ground Plane
Gerber\PIC16F18446_Curiosity_Nano_release_rev8.GTS : Gerber files for Top Solder
Gerber\PIC16F18446_Curiosity_Nano_release_rev8.GBS : Gerber files for Bottom Solder
Gerber\PIC16F18446_Curiosity_Nano_release_rev8.GM1 : Gerber files for Board (M1)
Gerber\PIC16F18446_Curiosity_Nano_release_rev8.GBL : Gerber files for Bottom Layer
Gerber\PIC16F18446_Curiosity_Nano_release_rev8.GBO : Gerber files for Bottom Overlay
Gerber\PIC16F18446_Curiosity_Nano_release_rev8.GTP : Gerber files for Top Paste
Gerber\PIC16F18446_Curiosity_Nano_release_rev8.GTO : Gerber files for Top Overlay
Gerber\PIC16F18446_Curiosity_Nano_release_rev8.GTL : Gerber files for Top-Layer
NC Drill\PIC16F18446_Curiosity_Nano_release_rev8.LDP : Layer Pairs Definition
